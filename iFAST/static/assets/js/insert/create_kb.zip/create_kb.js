$(document).ready(function() {


    const sequenceIdInput = $('#sequenceid');
    const nextButton = $('#next2');
    const prevButton = $('#prev5');
    const steps = $('.step');

    let formStepsNum = 0;

    function updateForm() {
        // Update sequence ID
        sequenceIdInput.val(`${formStepsNum + 1}`);

        // Update steps
        steps.removeClass('active');
        steps.each(function(index) {
            if (index <= formStepsNum) {
                $(this).addClass('active');
            }
        });
    }

    nextButton.on('click', function() {
        if (formStepsNum < steps.length - 1) {
            formStepsNum++;
        }
        updateForm();
    });

    prevButton.on('click', function() {
        if (formStepsNum > 0) {
            formStepsNum--;
        }
        updateForm();
    });

    updateForm();



    $('.dropdown').hover(function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(100).fadeIn(300).addClass('show');
    }, function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(100).fadeOut(300).removeClass('show');
    });


    $("#advsrch-link").on("click", function() {
        $("#advsrch").toggle();
        //$('#search').hide();

    });
    $('#resetBtn').on('click', function() {
        $('#searchID').val("");
        $('#select_SW, #select_Tech, #select_kpi, #select_Area').each(function() {
            var firstOption = $(this).find('option:first');
            $(this).val(firstOption.val()).trigger('change');
        });
    });
    $('#searchForm').validate({
        rules: {
            issue_sw: {
                required: true
            },
            rca: {
                required: true
            },
            area_val: {
                required: true
            },
            tech: {
                required: true
            },
            Visibility: {
                required: true
            },
            kpi: {
                required: true
            },
            rca: {
                required: true
            },
        },
        messages: {
            issue_sw: {
                required: "SW field is required"
            },
            rca: {
                required: "Root Cause field is required"
            },
            area_val: {
                required: "Area field is required"
            },
            tech: {
                required: "Technology field is required"
            },

        },
        errorPlacement: function(error, element) {
            error.appendTo(element.parent()); // Adjust the placement of the error message
        }
    });
    console.log($('#IssueSequenceForm'));
    $('#IssueSequenceForm').validate({
        rules: {
            action_type: {
                required: true
            },
            scName: {
                required: true
            },
            uid: {
                required: true
            },
            pwd: {
                required: true
            },
            ip: {
                required: true
            },
            scLoc: {
                required: true
            },
            scOwner: {
                required: true
            },
            scPath: {
                required: true
            },
        },
        messages: {
            action_type: {
                required: "Action type is Mandatory"
            },
            scName: {
                required: "Script name is Mandatory"
            },
            uid: {
                required: "UserName is required"
            },
            pwd: {
                required: "Password is required"
            },
            ip: {
               required: "IP is required"
            },
            scLoc: {
                required: "Server Location is required"
            },
            scOwner: {
                required: "script owner is required"
            },
            scPath: {
                required: "location of script(path) field is required"
            },
        },
        errorPlacement: function(error, element) {
            error.appendTo(element.parent()); // Adjust the placement of the error message
        }
    });

$('#save_btn').on('click',function(){
var IssueSequenceFormData = $('#IssueSequenceForm').serialize();
console.log(IssueSequenceFormData);
                $.ajax({
                    url: "/insert_issue_seq",
                    type: "post",
                    data: IssueSequenceFormData,
                    success: function(data) {
                        if (data.message) {
                            if (data.redirect_url) {
                                $('#exampleModal').modal('show');
                                $('#modalMessage').html(data.message);
                                $('#update_kb').hide();
                                $('#searchForm :input').prop('readonly', true);
                                $('#searchForm textarea').prop('readonly', true);
                                $('#redirectModalButton').on('click', function() {
                                    window.location.href = data.redirect_url;
                                });
                            } else {
                                $('#update_ret').html(data.message).removeClass('text-danger').addClass('text-success');
                            }
                        } else {
                            $('#update_ret').html(data.error).removeClass('text-success').addClass('text-danger');
                        }
                    },
                });
});

//        $('#update_kb').on('click', function() {
//            // Validate searchForm
//            var searchFormValid = $('#searchForm').valid();
//            var searchFormErrors = [];
//            if (!searchFormValid) {
//                $('#searchForm .error').each(function() {
//                    var fieldName = $(this).prev('label').text().replace('*', '').trim();
//                    fieldName = fieldName.split(':')
//                    var errorMessage = $(this).text();
//                    searchFormErrors.push(fieldName[0]);
//                });
//            }
//
//            // Validate IssueSequenceForm
//            var issueSequenceFormValid = $('#IssueSequenceForm').valid();
//            var issueSequenceFormErrors = [];
//            if (!issueSequenceFormValid) {
//                $('#IssueSequenceForm .error').each(function() {
//                    var fieldName = $(this).prev('label').text().replace('*', '').trim();
//                    fieldName = fieldName.split(':')
//                    var errorMessage = $(this).text();
//                    issueSequenceFormErrors.push(fieldName[0]);
//                });
//            }
//
//            // Combine error messages from both forms
//            var errorMessages = searchFormErrors.concat(issueSequenceFormErrors);
//            var errorMessageText = errorMessages.join('<br>');
//
//            // Display error message if any field is missing in either form
//            if (errorMessages.length > 0) {
//                Swal.fire({
//                    icon: 'error',
//                    title: 'Required fields are missing',
//                    html: errorMessageText
//                });
//            } else {
//                // Proceed with AJAX call to update the forms
//                var formData = $('#searchForm').serialize();
//                $.ajax({
//                    url: "/insert_kb",
//                    type: "post",
//                    data: formData,
//                    success: function(data) {
//                        if (data.message) {
//                            if (data.redirect_url) {
//                                $('#exampleModal').modal('show');
//                                $('#modalMessage').html(data.message);
//                                $('#update_kb').hide();
//                                $('#searchForm :input').prop('readonly', true);
//                                $('#searchForm textarea').prop('readonly', true);
//                                $('#redirectModalButton').on('click', function() {
//                                    window.location.href = data.redirect_url;
//                                });
//                            } else {
//                                $('#update_ret').html(data.message).removeClass('text-danger').addClass('text-success');
//                            }
//                        } else {
//                            $('#update_ret').html(data.error).removeClass('text-success').addClass('text-danger');
//                        }
//                    },
//                });
//            }
//        });



    $('#update_kb').on('click', function() {
        var formData = $('#searchForm').serialize();
        var errorMessages = [];
        if (!$('#searchForm').valid()) {
            $('#searchForm .error').each(function() {
                var fieldName = $(this).prev('label').text().replace('*', '').trim();
                fieldName = fieldName.split(':')
                var errorMessage = $(this).text();
                errorMessages.push(fieldName[0]);
            });
            var errorMessageText = errorMessages.join('<br>');

            Swal.fire({
                icon: 'error',
                title: 'Required fields are missing',
                html: errorMessageText
            });
        } else{
            $.ajax({
                url: "/insert_kb",
                type: "post",
                data: formData,
                success: function(data) {
                    if (data.message) {
                        if (data.redirect_url) {
                            $('#exampleModal').modal('show');
                            $('#modalMessage').html(data.message);
                            $('#update_kb').hide();
                            $('#searchForm :input').prop('readonly', true);
                            $('#searchForm textarea').prop('readonly', true);
                            $('#redirectModalButton').on('click', function() {
                                window.location.href = data.redirect_url;
                            });
                        } else {
                        $('#issue_id').val(data.issue_id);
                        $('#nav-profile-tab').tab('show');
                            //$('#update_ret').html(data.message).removeClass('text-danger').addClass('text-success');
                        }
                    } else {
                        $('#issue_id').val(data.issue_id);
                        $('#nav-profile-tab').tab('show');
                    }
                },
            });
        }
    });
});