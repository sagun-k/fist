@app.route("/insert_issue_seq",methods=['GET','POST'])
def insert_issue_seq():
    issue_id =request.form.get('issue_id')
    action_id =request.form.get('action_id')
    sw_val = request.form.get('sw_val')
    seq_id = request.form.get('sequenceid')
    status_val = request.form.get('status_val')
    prev_act_type = request.form.get('prev_action_type')
    act_type = request.form.get('action_type')
    scname = request.form.get('scName')
    uid = request.form.get('uid')
    pwd = request.form.get('pwd')
    ip = request.form.get('ip')
    scloc = request.form.get('scLoc')
    scowner = request.form.get('scOwner')
    scpath = request.form.get('scPath')
    c_type = request.form.get('check_type')
    proceed = request.form.get('proceed')
    c_cond = request.form.get('check_condition')
    args = request.form.get('regex')
    om_counters = request.form.get('om_counters')
    grep = request.form.get('pattern_grep')

    if not action_id:
       return post_issue_sequence(issue_id, sw_val, act_type, status_val, scname, seq_id, args, c_type, proceed, c_cond, grep, om_counters, ip, uid, pwd, session)
    else:
       return update_issue_sequence(issue_id, sw_val, act_type, status_val, scname, seq_id, args, c_type, proceed, c_cond, grep, om_counters, ip, action_id, prev_act_type, uid, pwd, session)
    


def post_issue_sequence( issue_id, sw_val, act_type, status_val, scname, seq_id,args, c_type, proceed, c_cond, grep, om_counters, ip, uid, pwd, session):
    existing_exec_order = get_exec_orders(issue_id) #fetching the exec orders
    new_added_child = determine_action_type_and_add(issue_id, sw_val, act_type, status_val, scname, seq_id,args, c_type, proceed, c_cond, grep, om_counters, ip, uid, pwd, session)
    #mapping the action_id
    existing_exec_order.append(map_action_type_id(act_type, new_added_child))
    update_exec_orders(issue_id, existing_exec_order)
    return jsonify({"message": "Inserted successfully","action_id":new_added_child}), 201


def update_issue_sequence(issue_id, sw_val, act_type, status_val, scname, seq_id,args, c_type, proceed, c_cond, grep, om_counters, ip, action_id, prev_act_type, uid, pwd, session):
    exec_orders = get_exec_orders(issue_id)
    if not is_action_type_changed(act_type, action_id, exec_orders):
        return update_when_action_type_not_changed(sw_val, act_type, status_val, scname, seq_id, args, c_type, proceed, c_cond, grep, om_counters, ip, action_id, uid, pwd, session)
    else :
        return update_when_action_type_changed(sw_val, act_type, status_val, scname, seq_id, args, c_type, proceed, c_cond, grep, om_counters, ip, action_id, prev_act_type, issue_id, uid, pwd,session)        



def update_or_insert_user_credentials_when_type_cli(uid, pwd, session):
    if uid and pwd:
        hashed_pwd = pwd
        if not pwd.startswith(("$2a$", "$2b$", "$2y$")):
            hashed_pwd = bcrypt.hashpw(
                base64.b64encode(hashlib.sha256(pwd.encode('utf-8')).digest()),
                bcrypt.gensalt()
            ).decode('utf-8') 
        select_query = "SELECT * FROM user_sane_details WHERE user_id=%s"
        values = (session['user_name'],)
        result = db.execute_query(select_query, values)

        if result:
            if not (result[0]['sane_id'] == uid and result[0]['sane_password'] == hashed_pwd):
                db.execute_query(
                    """UPDATE user_sane_details SET sane_id=%s, sane_password=%s WHERE user_id=%s""",
                    (uid, hashed_pwd, session['user_name']),
                    commit=True
                )
        else:
            db.execute_query(
                "INSERT INTO user_sane_details (user_id, sane_id, sane_password) VALUES (%s, %s, %s)",
                (session['user_name'], uid, hashed_pwd),
                commit=True
            )


def determine_action_type_and_add(issue_id, sw_val, act_type, status_val, scname, seq_id,args, c_type, proceed, c_cond, grep, om_counters, ip, uid, pwd, session):
    new_added_child = None
    if act_type == "RUN CLI":
        new_added_child = add_cli(sw_val, act_type, status_val, scname,ip, seq_id,args, c_type, proceed, c_cond)
        update_or_insert_user_credentials_when_type_cli(uid, pwd, session)
    elif act_type == "PULL OM":
        new_added_child = add_om(status_val, act_type, scname, ip,seq_id, proceed, c_cond, om_counters)
    elif act_type == "RUN GREP":
        new_added_child = add_grep(seq_id, grep, act_type)
    else:
        raise Exception("Invalid action type")
    return new_added_child

def update_when_action_type_not_changed(sw_val, act_type, status_val, scname, seq_id,args, c_type, proceed, c_cond, grep, om_counters, ip, action_id, uid, pwd, session):
    updated_child = None
    if act_type == "RUN CLI":
            updated_child = update_cli(sw_val, act_type, status_val, scname, ip, seq_id, args, c_type, proceed, c_cond, action_id)
            update_or_insert_user_credentials_when_type_cli(uid, pwd, session)
    elif act_type == "PULL OM":
        updated_child = update_om(status_val, act_type, scname, ip, om_counters, proceed, c_cond, seq_id, action_id)
    elif act_type == "RUN GREP":
        updated_child = update_grep(act_type, seq_id, grep, action_id)
    else:
        raise Exception("Invalid action type")
    return jsonify({"message":"Updated issue successfully","action_id":updated_child}), 201

def update_when_action_type_changed(sw_val, act_type, status_val, scname, seq_id,args, c_type, proceed, c_cond, grep, om_counters, ip, action_id, prev_act_type, issue_id, uid, pwd, session):
    exec_orders = get_exec_orders(issue_id)
    previous_existed_exec_id = map_action_type_id(prev_act_type, action_id)
    current_exec_position = find_index_of_current_exec(exec_orders, previous_existed_exec_id)
    delete_existed_exec(prev_act_type, action_id)
    new_added_data_id = determine_action_type_and_add(issue_id, sw_val, act_type, status_val, scname, seq_id, args, c_type, proceed, c_cond, grep, om_counters, ip, uid, pwd, session)
    new_exec_id = map_action_type_id(act_type, new_added_data_id)
    updated_exec_order = update_value_of_exec_order_in_specific_index(exec_orders, current_exec_position, new_exec_id)
    update_exec_orders(issue_id, updated_exec_order)
    return jsonify({"message":"Updated issue successfully","action_id":new_added_data_id}), 201

    
def update_value_of_exec_order_in_specific_index(exec_orders, index, new_value_in_index):
    if 0 <= index < len(exec_orders):
        exec_orders[index] = new_value_in_index  # Update the value at the specified index
    else:
        print("Index out of range. No updates made.")

    return exec_orders  #



def find_index_of_current_exec(exec_orders, previous_existed_exec_id):
    for index, exec_order in enumerate(exec_orders):
        if exec_order == previous_existed_exec_id:
            return index  # Return the index if a match is found

    return -1      

def delete_existed_exec(prev_act_type, action_id):
    DB_TABLE = ACTION_DB_MAPPPING.get(prev_act_type, None)
    delete_query = f"DELETE FROM {DB_TABLE} WHERE {action_id}=%s "
    db.execute_query(delete_query, action_id, commit=True)



def map_action_type_id(act_type, id):
    if act_type == "RUN CLI":
        return "CLI_"+str(id)
    elif act_type == "PULL OM":
        return "OM_"+str(id)
    elif act_type == "RUN GREP":
        return "GREP_"+str(id)


def is_action_type_changed(action_type, action_id, exec_orders):
    exec_id = map_action_type_id(action_type, action_id)
    exec_index = find_index_of_current_exec(exec_orders, exec_id)
    return exec_index == -1
        
def add_cli(sw_val, act_type, status_val, scname, ip, seq_id, args, c_type, proceed, c_cond):
    insert_query = """INSERT INTO scripts (SW, action_type, Status, script_name,  Server_IP, Sequence_num, args, check_type, proceed, check_condition, email_to, counter_info) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
    values = ( sw_val, act_type, status_val, scname,  ip, seq_id,args,c_type,proceed,c_cond,"", "")
    db.execute_query(insert_query, values)
    return db.last_insert_id()

def update_cli(sw_val, act_type, status_val, scname, ip, seq_id, args, c_type, proceed, c_cond, action_id):
    action = action_mapp[act_type]
    update_query = f"""UPDATE scripts SET SW=%s, action_type=%s, Status=%s, script_name=%s,  Server_IP=%s, 
    Sequence_num=%s, args=%s, check_type=%s, proceed=%s, check_condition=%s, email_to=%s, counter_info=%s
    WHERE {action}=%s """
    values = (sw_val, act_type, status_val, scname,  ip, seq_id, args, c_type, proceed, c_cond, "", "", action_id)
    db.execute_query(update_query, values, commit=True)
    return action_id

def add_grep(seq_id, grep, act_type):
    insert_query = """ INSERT INTO grep (Sequence_num, grep_target,  action_type) VALUES(%s,%s,%s) """
    values = (seq_id,grep,act_type)
    db.execute_query(insert_query, values)
    return db.last_insert_id()


def update_grep( act_type, seq_id, grep, action_id):
    action = action_mapp[act_type]
    update_query = f"""UPDATE grep SET Sequence_num=%s, grep_target=%s, action_type=%s WHERE {action}=%s """
    values = (seq_id,grep,act_type,action_id)
    db.execute_query(update_query, values)
    return action_id

def add_om(status_val,act_type,scname,ip, seq_id, proceed,c_cond, om_counters):
    insert_query = """INSERT INTO OM_EXEC (Status, action_type, script_name, Server_IP,Sequence_num,  proceed, check_condition, counter_info)VALUES(%s, %s, %s, %s, %s, %s, %s, %s)"""
    values = (status_val,act_type,scname,ip, seq_id, proceed,c_cond, om_counters)
    db.execute_query(insert_query, values)
    return db.last_insert_id()


def update_om(status_val, act_type, scname, ip, om_counters, proceed, c_cond, seq_id, action_id):
    action = action_mapp[act_type]
    update_query = f"""UPDATE om_exec SET Status=%s, action_type=%s, script_name=%s,Server_IP=%s,counter_info=%s, proceed=%s, check_condition=%s, Sequence_num=%s WHERE {action}=%s """
    values = (status_val, act_type, scname, ip, om_counters, proceed, c_cond, seq_id, action_id)
    db.execute_query(update_query, values)
    return action_id

def get_exec_orders(issue_id):
    try:
        result = db.execute_query(
            'SELECT EXEC_ORDER FROM known_knowledge_base WHERE issue=%s',
            (issue_id,),
            fetch_all=False
        )
        
        if result and 'EXEC_ORDER' in result and result['EXEC_ORDER'] is not None:
            return result['EXEC_ORDER'].split(',')
        else:
            return []
    except Exception as e:
        print(f"Error fetching execution orders for issue_id {issue_id}: {e}")
        abort(500, description="Internal Server Error: Could not fetch execution orders.")

def update_exec_orders(issue_id, new_exec_order):
     print(new_exec_order)
     new_exec_order_string = ",".join(new_exec_order)  
     db.execute_query('UPDATE known_knowledge_base SET EXEC_ORDER=%s WHERE issue=%s ',
                                                       (new_exec_order_string, issue_id), commit=True)



