function changeFunction(idx){
    console.log("changeFunction")
         id_selector = '#issue_sequence_card_1'
         formId = '#IssueSequenceForm'
         if (idx){
            id_selector = '#issue_sequence_card_' + idx
            formId = '#IssueSequenceForm' + idx
            }
        // debugger
        idx = idx?idx:1
        var selector = $(id_selector)
        var $form =  selector.find(formId)
      //  debugger
        // Collect all form inputs
        $form.find('input, textarea, select').each(function() {
            let $input = $(this);
            let inputType = $input.attr('type');

            // Handle different input types
            if (inputType === 'checkbox') {
                $input.prop('checked', false);
            }
            else if (inputType === 'radio') {
                if ($input.is(':checked')) {
                    $input.prop('checked', false);
                }
            } else  {
                // debugger
                let excludedIds = ['issue_id', 'status_val', 'sequenceid', 'action_type', `savebtn_${idx}`, `editbtn_${idx}`,'action_id', 'sw_val' ];
                if (!excludedIds.includes($input.attr('id'))) {
                     $input.val('');
                }




            }
        });



    var selval =  selector.find(formId).find("#action_type").val()
         if (selval === "PULL OM"){
             selector.find(formId).find('#scName').closest('div').hide();
             selector.find(formId).find('#ip').closest('div').hide();
             selector.find(formId).find('#scLoc').closest('div').hide();
             selector.find(formId).find('#scOwner').closest('div').hide();
             selector.find(formId).find('#scPath').closest('div').hide();
             selector.find(formId).find('#uid').closest('div').hide();
             selector.find(formId).find('#pwd').closest('div').hide();
             selector.find(formId).find('#check_condition').closest('div').show();
             selector.find(formId).find('#regex').closest('div').hide();
             selector.find(formId).find('#om_counters').closest('div').show();
             selector.find(formId).find('#pattern_grep').closest('div').hide();

             selector.find(formId).find('.checkbox-group').children().show();
        }else if(selval === "RUN CLI" ) {
             selector.find(formId).find('#uid').closest('.form-group').show();
             selector.find(formId).find('#pwd').closest('.form-group').show();

          //   selector.find(formId).find('#uid').prop('disabled', true);
          //   selector.find(formId).find('#pwd').prop('disabled', true);


             selector.find(formId).find('#scName').closest('div').hide();
             selector.find(formId).find('#ip').closest('div').hide();
             selector.find(formId).find('#scLoc').closest('div').hide();
             selector.find(formId).find('#scOwner').closest('div').hide();
             selector.find(formId).find('#scPath').closest('div').hide();
             selector.find(formId).find('#om_counters').closest('div').hide();
             selector.find(formId).find('#check_condition').prev('label').text('Command:');
             selector.find(formId).find('#check_condition').closest('div').show();
             selector.find(formId).find('#regex').closest('div').hide();
             selector.find(formId).find('#pattern_grep').closest('div').hide();
             selector.find(formId).find('.checkbox-group').children().show();
        }  else if(selval === "RUN GREP" ) {
             selector.find(formId).find('#uid').closest('.form-group').hide();
             selector.find(formId).find('#pwd').closest('.form-group').hide();
             selector.find(formId).find('#scName').closest('div').hide();
             selector.find(formId).find('#ip').closest('div').hide();
             selector.find(formId).find('#scLoc').closest('div').hide();
             selector.find(formId).find('#scOwner').closest('div').hide();
             selector.find(formId).find('#scPath').closest('div').hide();
             selector.find(formId).find('#check_condition').closest('div').hide();
             selector.find(formId).find('#regex').closest('div').hide();
             selector.find(formId).find('#om_counters').closest('div').hide();
             selector.find(formId).find('#pattern_grep').closest('div').show();
             selector.find(formId).find('.checkbox-group').children().hide();
        } else {
             selector.find(formId).find('#scName').closest('.form-group').show();
             selector.find(formId).find('#ip').closest('.form-group').show();
             selector.find(formId).find('#scLoc').closest('.form-group').show();
             selector.find(formId).find('#scOwner').closest('.form-group').show();
             selector.find(formId).find('#scPath').closest('.form-group').show();
             selector.find(formId).find('#pattern_grep').closest('div').hide();
             selector.find(formId).find('#check_condition').closest('div').show();
             selector.find(formId).find('#regex').closest('div').show();
             selector.find(formId).find('#om_counters').closest('div').hide();
             selector.find(formId).find('.checkbox-group').children().show();
                //$('.checkbox-group').show(); // Show the entire checkbox group
        }


    }